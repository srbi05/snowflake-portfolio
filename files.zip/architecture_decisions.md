# Architecture Decision Log
## Northside Regional Medical Center — BI Analytics Project

This document records all significant technical decisions made during the project,
the options considered, and the rationale for each choice.

---

## ADR-001: DirectQuery vs Import Mode

**Date:** June 2025  
**Status:** Decided

**Context:**  
Power BI offers two data connection modes: Import (data copied into Power BI memory)
and DirectQuery (queries sent live to Snowflake on demand).

**Options Considered:**

| Option | Pros | Cons |
|---|---|---|
| Import Mode | Fast visuals, full DAX support, works offline | Data staleness (up to 8 refreshes/day), memory limits at scale |
| DirectQuery | Always fresh data, no storage limits, single source of truth | Slower visuals, limited DAX functions, RANDBETWEEN blocked |

**Decision:** DirectQuery

**Rationale:**  
Clinical staff (nursing, COO) need occupancy and delay data that is no more than 4 hours old.
Import mode with 8 refreshes/day creates windows where the dashboard shows yesterday's
ICU census. For a hospital making bed allocation decisions, stale data creates risk.

**Consequences:**  
- RANDBETWEEN() not supported → solved via Snowflake UNIFORM() column
- Some complex DAX patterns unavailable → pre-aggregated views in Snowflake compensate
- Visual render speed slightly slower → mitigated by Snowflake X-Small warehouse

---

## ADR-002: JSON Flattening — Snowflake View vs Power Query

**Date:** June 2025  
**Status:** Decided

**Context:**  
EMR system exports diagnosis codes as JSON arrays stored in a VARIANT column:
`{"codes": ["I21.0", "J18.9"], "primary": "I21.0"}`

This needs to be flattened to one row per diagnosis code for filtering in Power BI.

**Options Considered:**

| Option | Approach |
|---|---|
| Power Query | Use Table.ExpandListColumn on parsed JSON |
| Snowflake View | LATERAL FLATTEN on VARIANT column |

**Decision:** Snowflake View (VW_ADT_WITH_DIAGNOSES)

**Rationale:**  
Power Query JSON parsing on DirectQuery sends the full VARIANT column to the
client for each query. At 1M+ rows in production, this causes timeout errors
and memory exhaustion. Snowflake LATERAL FLATTEN executes server-side with
full columnar compression, returning only the flattened rows Power BI needs.

**Consequences:**  
- View must be maintained in Snowflake when JSON schema changes
- Power BI connects to the view, not the raw table

---

## ADR-003: LOS_REALISTIC Column Placement

**Date:** June 2025  
**Status:** Decided

**Context:**  
The synthetic dataset had uniform LOS values (10–13 days) across all units,
preventing the Key Influencers AI visual from detecting meaningful patterns.
A unit-specific LOS distribution was needed.

**Options Considered:**

| Option | Approach | Works in DirectQuery? |
|---|---|---|
| DAX Calculated Column | RANDBETWEEN() based on UNIT | No — volatile functions blocked |
| Power Query Column | Custom column with if/then | No — evaluated at refresh, not stored |
| Snowflake Column | UNIFORM() + RANDOM() via UPDATE | Yes — stored static values |

**Decision:** Snowflake UPDATE statement adding LOS_REALISTIC column

**Rationale:**  
Transformations in DirectQuery mode must produce static, stored values.
UNIFORM() in Snowflake runs once at UPDATE time and stores the result —
equivalent to how a production EMR would store the computed LOS from
actual admit/discharge timestamps. This is the architecturally correct pattern.

---

## ADR-004: Row-Level Security Implementation Layer

**Date:** June 2025  
**Status:** Decided

**Context:**  
Nursing unit heads should see only their unit's data. RLS can be implemented
at the Snowflake layer (Row Access Policies) or the Power BI layer (Manage Roles).

**Options Considered:**

| Option | Implementation | Pros | Cons |
|---|---|---|---|
| Snowflake Row Access Policy | SQL policy on UNIT column | Enforced at data layer | Requires Snowflake Enterprise, complex setup |
| Power BI RLS | Modeling > Manage Roles | Native Azure AD integration, simple setup | Only enforced in Power BI Service, not direct Snowflake access |

**Decision:** Power BI RLS mapped to Azure AD groups

**Rationale:**  
The client's nursing staff only access data through Power BI dashboards.
There is no requirement for direct Snowflake access by end users.
Power BI RLS with Azure AD group mapping is the simpler, faster,
and more maintainable solution for this use case.

**Consequences:**  
- If any user gains direct Snowflake access, RLS is not enforced there
- Snowflake RLS SQL documented in 04_optimization/row_level_security.sql for future upgrade

---

## ADR-005: Discharge_Delays Relationship Cardinality

**Date:** June 2025  
**Status:** Decided (corrected during build)

**Context:**  
Initial assumption was that each patient has exactly one discharge delay record
(One-to-One relationship with ADT_Fact). Power BI rejected this with error:
"Column PATIENT_ID contains duplicate values."

**Root Cause:**  
One patient can have multiple hospital visits and therefore multiple delay records.
The initial assumption was clinically incorrect.

**Decision:** Many-to-One relationship (Discharge_Delays → ADT_Fact)

**Rationale:**  
`PATIENT_ID` in `Discharge_Delays` repeats because:
1. Same patient can be admitted multiple times (readmissions)
2. Same patient can have delays on different discharge dates
Cross-filter direction set to Single to prevent ambiguous filter paths.
