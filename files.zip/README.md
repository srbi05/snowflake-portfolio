# Northside Regional Medical Center — BI Analytics Project

![Snowflake](https://img.shields.io/badge/Snowflake-29B5E8?style=flat&logo=snowflake&logoColor=white)
![Power BI](https://img.shields.io/badge/Power%20BI-F2C811?style=flat&logo=powerbi&logoColor=black)
![SQL](https://img.shields.io/badge/SQL-Snowflake%20SQL-blue)
![DAX](https://img.shields.io/badge/DAX-Power%20BI-yellow)

## Project Overview

End-to-end BI analytics solution for a 750-bed multi-specialty hospital system.
Built on Snowflake as the cloud data warehouse and Power BI as the reporting layer,
covering patient flow, revenue cycle management, predictive readmission risk scoring,
and patient sentiment analysis.

**Client:** Northside Regional Medical Center  
**Role:** BI Consultant — Data Modeling, Dashboard Design, AI Integration  
**Sprint:** 3 weeks  
**Stakeholders:** COO, CFO, CMO, Head of Nursing, HR Director

---

## Solution Architecture

```
EMR System / Billing / HR
        │
        ▼
  Snowflake (HOSPITAL_DW)
  ├── SNOW_ADT_FACT          ← Patient admissions/discharges
  ├── SNOW_BED_MASTER        ← Unit capacity reference
  ├── SNOW_DISCHARGE_DELAYS  ← Delay tracking
  ├── SNOW_REVENUE_FACT      ← Claims and denials
  └── VW_ADT_WITH_DIAGNOSES  ← Flattened JSON view (LATERAL FLATTEN)
        │
        ▼ DirectQuery (refreshes every 4 hours)
  Power BI Desktop
  ├── Star Schema Data Model
  ├── 15 DAX Measures
  └── 4 Dashboard Pages
      ├── Bed Utilization + AI Anomaly Detection
      ├── Revenue Cycle + Denial Management
      ├── Predictive Readmission (Azure ML)
      └── Patient Sentiment (NLP)
```

---

## Key Technical Decisions

| Decision | Choice | Rationale |
|---|---|---|
| Connection mode | DirectQuery (not Import) | Hospital data refreshes every 4 hrs — Import mode would serve stale data to clinical staff |
| JSON flattening | Snowflake LATERAL FLATTEN view | Parsing VARIANT columns in Power Query causes severe performance degradation at scale |
| LOS computation | LOS_REALISTIC added in Snowflake via UNIFORM() | RANDBETWEEN() is unsupported in DirectQuery — transformations must live at the source layer |
| Incremental refresh | PARTITION_MONTH column in Snowflake | Reduces Power BI refresh window from full-table scan to 1-month slice |
| Relationship cardinality | Discharge_Delays → ADT_Fact as Many-to-One | One patient can have multiple delay events — One-to-One blocked valid duplicate PATIENT_IDs |
| Row-Level Security | Unit-based RLS mapped to Azure AD groups | Nursing heads see only their floor data, enforced at the report layer |

---

## Snowflake Objects

| Object | Type | Purpose |
|---|---|---|
| `HOSPITAL_DW` | Database | Central data warehouse for all hospital analytics |
| `ANALYTICS_WH` | Virtual Warehouse | X-Small compute, auto-suspend 120s, auto-resume |
| `SNOW_ADT_FACT` | Table | Core patient admission, discharge, transfer records |
| `SNOW_BED_MASTER` | Table | Unit capacity, bed type, target occupancy reference |
| `SNOW_DISCHARGE_DELAYS` | Table | Delay reason codes, minutes, escalation flags |
| `SNOW_REVENUE_FACT` | Table | Insurance claims, billed/paid/denied amounts |
| `VW_ADT_WITH_DIAGNOSES` | View | Flattened VARIANT JSON diagnosis codes via LATERAL FLATTEN |

---

## Power BI Data Model

```
DateTable ──────────────────────────────────────────┐
     │                                               │
     │ (Many-to-One via ADMIT_DATE)          (Many-to-One via SERVICE_DATE)
     ▼                                               ▼
ADT_Fact (Fact) ──── BED_ID ──► Bed_Master     Revenue_Fact
     │
     │ (One-to-Many via PATIENT_ID)
     ▼
Discharge_Delays

AI_Readmission ──── PATIENT_ID ──► ADT_Fact   (Many-to-One, cross-filter: Both)
AI_NLP_Feedback ─── UNIT ────────► Bed_Master (Many-to-One)
AI_Anomaly_Flags ── UNIT ────────► Bed_Master (Many-to-One)
```

---

## DAX Measures — 15 Total

| Measure | Category | Purpose |
|---|---|---|
| `Bed Occupancy %` | Bed Ops | Active patients / total capacity |
| `ALOS Days` | Bed Ops | Average length of stay (discharged patients only) |
| `Occupancy Alert` | Bed Ops | CRITICAL / WATCH / NORMAL flag |
| `Delay Rate %` | Delays | % of patients with discharge delays |
| `Denial Rate %` | Revenue | % of claims denied |
| `Net Collection Rate %` | Revenue | Paid / Billed across all claims |
| `Avg Days to Payment` | Revenue | Avg time from submission to payment |
| `High Risk Patients` | AI/ML | Count of RISK_TIER = HIGH from Azure ML |
| `Avg Risk Score` | AI/ML | Mean readmission probability score |
| `Avg Sentiment Score` | NLP | Mean patient feedback sentiment (0-1) |
| `Negative Feedback Count` | NLP | Count of negative sentiment records |
| `Critical Anomalies` | Anomaly | Count of SEVERITY = Critical in anomaly log |
| `LOS Completed` | Bed Ops | ALOS filtered to discharged patients only |
| `Beds in Critical Zone` | Bed Ops | Units with occupancy >= 85% |
| `OT Cost Total` | HR | Sum of OT hours x OT rate across staff |

---

## AI Scenarios Implemented in Power BI

| Visual | Page | Business Question Answered |
|---|---|---|
| Key Influencers | AI Insights | What drives patients to have a long LOS? |
| Decomposition Tree | AI Insights | Why did ICU occupancy spike on Tuesday? |
| Q&A Natural Language | Nursing Q&A | Self-service querying for nursing staff |
| Anomaly Detection | Anomaly Monitor | Which occupancy spikes were statistically unusual? |
| Smart Narrative | Executive dashboard | Auto-written paragraph summary for COO |
| Sentiment Dashboard | Patient Sentiment | Which units have the lowest patient satisfaction? |

---

## Challenges and How I Solved Them

**Problem:** RANDBETWEEN() not supported in DirectQuery mode  
**Solution:** Pushed LOS_REALISTIC as a computed column into Snowflake using
UNIFORM() + RANDOM() — correct pattern for production environments where
transformations belong at the source layer, not inside Power BI.

**Problem:** Key Influencers visual returned no results  
**Solution:** Diagnosed root cause via DAX SUMMARIZE query — identified
insufficient LOS variance across units in synthetic data (all units 10-13 days).
Fixed at Snowflake layer by applying realistic unit-based LOS distributions.

**Problem:** Discharge_Delays PATIENT_ID contained duplicate values  
**Solution:** Corrected relationship cardinality from One-to-One to Many-to-One.
One patient can have multiple delay events across different admissions.

**Problem:** Revenue CSV failing with numeric value not recognized  
**Solution:** Pre-processed CSV files to strip currency symbols and thousand
separators before Snowflake ingestion. Documented as a data preparation standard.

---

## How to Run This Project

1. Create a Snowflake free trial at https://signup.snowflake.com
2. Run scripts in order: 01_setup then 02_views then 03_transformations then 04_optimization
3. Connect Power BI Desktop via Get Data > Snowflake > DirectQuery
4. Import DAX measures from /powerbi/dax/ files
5. Apply RLS roles via Modeling > Manage Roles in Power BI Desktop

---

*Built as part of a healthcare analytics consulting simulation.*  
*All data is synthetic — no real patient data used.*
