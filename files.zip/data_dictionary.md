# Data Dictionary
## Northside Regional Medical Center — BI Analytics Project

---

## SNOW_ADT_FACT

| Column | Data Type | Description | Example |
|---|---|---|---|
| PATIENT_ID | VARCHAR(10) | Unique patient identifier. Non-unique at table level — patients can be readmitted | PT0042 |
| ADMIT_DATE | DATE | Date patient was admitted | 2024-03-15 |
| ADMIT_TIME | VARCHAR(5) | Time of admission in HH:MM format | 14:30 |
| DISCHARGE_DATE | DATE | Date patient was discharged. NULL = still admitted | 2024-03-22 |
| DISCHARGE_TIME | VARCHAR(5) | Time of discharge | 09:00 |
| UNIT | VARCHAR(20) | Clinical unit. Values: ICU, General, Maternity, Pediatrics, ER, Oncology, Orthopedics | ICU |
| BED_ID | VARCHAR(15) | Bed identifier. Format: [UNIT_PREFIX]-B[NN] | ICU-B03 |
| ADMIT_REASON | VARCHAR(50) | Primary reason for admission | Chest Pain |
| DISCHARGE_REASON | VARCHAR(30) | Reason for discharge. Active = still admitted | Recovered |
| ATTENDING_DOCTOR_ID | VARCHAR(10) | Attending physician ID | DR015 |
| INSURANCE_TYPE | VARCHAR(20) | Patient insurance category | Medicare |
| LOS_DAYS | NUMBER | Length of stay in days. NULL for active patients | 7 |
| DIAGNOSIS_CODES_JSON | VARIANT | JSON array of ICD-10 codes from EMR. Flattened via VW_ADT_WITH_DIAGNOSES | {"codes":["I21.0"],"primary":"I21.0"} |
| READMISSION_FLAG | NUMBER(1) | 1 = patient was readmitted within 30 days of prior discharge | 0 |
| PARTITION_MONTH | VARCHAR(7) | Derived from ADMIT_DATE for incremental refresh. Format: YYYY-MM | 2024-03 |
| LOS_REALISTIC | NUMBER | Unit-adjusted LOS for analytics. Computed via Snowflake UNIFORM() | 18 |

---

## SNOW_BED_MASTER

| Column | Data Type | Description | Example |
|---|---|---|---|
| BED_ID | VARCHAR(15) | Unit identifier. Joins to SNOW_ADT_FACT[BED_ID] | ICU-UNIT |
| UNIT | VARCHAR(20) | Clinical unit name | ICU |
| FLOOR | NUMBER | Floor number in the hospital building | 1 |
| BED_TYPE | VARCHAR(25) | Type of care provided | Critical Care |
| TOTAL_CAPACITY | NUMBER | Total number of beds in this unit | 10 |
| TARGET_OCC_PCT | NUMBER | Target occupancy % agreed with operations team | 85 |
| ICU_FLAG | VARCHAR(3) | Yes/No — whether unit is an intensive care unit | Yes |

---

## SNOW_DISCHARGE_DELAYS

| Column | Data Type | Description | Example |
|---|---|---|---|
| PATIENT_ID | VARCHAR(10) | Patient identifier. Many-to-One → SNOW_ADT_FACT | PT0042 |
| UNIT | VARCHAR(20) | Unit where delay occurred | ICU |
| EXPECTED_DISCHARGE | DATE | Date discharge was originally planned | 2024-03-20 |
| ACTUAL_DISCHARGE | DATE | Date discharge actually occurred | 2024-03-21 |
| DELAY_MINUTES | NUMBER | Total delay in minutes | 240 |
| DELAY_REASON_CODE | VARCHAR(10) | Code referencing delay category | DR001 |
| NURSE_ID | VARCHAR(8) | Nurse who logged the delay | RN007 |
| ESCALATED_FLAG | VARCHAR(3) | Yes if DELAY_MINUTES > 300 — triggers supervisor alert | No |

**Delay Reason Codes:**

| Code | Description | Avg Delay | Priority |
|---|---|---|---|
| DR001 | Awaiting Physician Sign-Off | 120 min | High |
| DR002 | Patient Transport Not Available | 90 min | Medium |
| DR003 | Pharmacy Medication Delay | 75 min | Medium |
| DR004 | Family Not Ready / Caregiver Absent | 180 min | High |
| DR005 | Bed Not Available at Receiving Facility | 240 min | Critical |

---

## SNOW_REVENUE_FACT

| Column | Data Type | Description | Example |
|---|---|---|---|
| CLAIM_ID | VARCHAR(10) | Unique claim identifier | CLM00042 |
| PATIENT_ID | VARCHAR(10) | Patient identifier | PT0042 |
| SERVICE_DATE | DATE | Date service was provided | 2024-03-15 |
| SUBMISSION_DATE | DATE | Date claim was submitted to insurer | 2024-03-18 |
| INSURANCE_TYPE | VARCHAR(20) | Insurance category | Medicare |
| BILLED_AMOUNT | NUMBER(10,2) | Amount billed to insurer — no $ symbol | 3401.09 |
| ALLOWED_AMOUNT | NUMBER(10,2) | Amount insurer agreed to pay | 2890.00 |
| PAID_AMOUNT | NUMBER(10,2) | Amount actually received | 2890.00 |
| DENIAL_CODE | VARCHAR(10) | CMS denial code if denied. NULL for paid claims | CO4 |
| DENIAL_REASON | VARCHAR(60) | Description of denial reason | Service not covered by plan |
| CLAIM_STATUS | VARCHAR(20) | Values: Paid, Denied, Pending, Partially Paid | Paid |
| DAYS_TO_PAYMENT | NUMBER | Days from SUBMISSION_DATE to payment. NULL if not paid | 28 |
| PARTITION_MONTH | VARCHAR(7) | Derived from SERVICE_DATE for incremental refresh | 2024-03 |

---

## AI_Readmission

| Column | Data Type | Description |
|---|---|---|
| PATIENT_ID | VARCHAR(10) | Links to SNOW_ADT_FACT |
| PREDICTION_DATE | DATE | Date Azure ML model was run |
| READMISSION_RISK_SCORE | DECIMAL | Probability 0.0 to 1.0 |
| RISK_TIER | VARCHAR(10) | HIGH (>0.70) / MEDIUM (0.40-0.70) / LOW (<0.40) |
| TOP_FACTOR_1/2/3 | VARCHAR | Top 3 contributing factors from ML model |
| ACTUAL_READMITTED_30D | NUMBER(1) | Actual outcome — 1 = readmitted within 30 days |

---

## AI_NLP_Feedback

| Column | Data Type | Description |
|---|---|---|
| FEEDBACK_ID | VARCHAR | Unique feedback record |
| PATIENT_ID | VARCHAR(10) | Links to SNOW_ADT_FACT |
| UNIT | VARCHAR(20) | Unit patient was in — links to SNOW_BED_MASTER |
| FEEDBACK_DATE | DATE | Date feedback was submitted |
| FEEDBACK_TEXT_SNIPPET | VARCHAR | Truncated feedback text (full text in source system) |
| SENTIMENT_LABEL | VARCHAR | Positive / Negative / Neutral |
| SENTIMENT_SCORE | DECIMAL | Score 0.0 (very negative) to 1.0 (very positive) |
| TOPIC_CATEGORY | VARCHAR | Staff Behavior / Wait Times / Billing / Room Quality etc. |
| FLAGGED_FOR_REVIEW | VARCHAR | Yes if Negative AND score < 0.20 |
